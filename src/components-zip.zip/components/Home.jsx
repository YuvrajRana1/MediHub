import React from 'react';

function Home() {
  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Welcome to Digi-Med</h1>
      <p className="text-gray-600 mb-4">Your digital healthcare companion for managing medical records, appointments, and prescriptions.</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
        <div className="bg-blue-50 p-6 rounded-lg shadow hover:shadow-md transition-shadow">
          <h2 className="text-xl font-semibold text-blue-700 mb-2">My Reports</h2>
          <p className="text-gray-600">Access and manage all your medical reports in one place.</p>
        </div>
        
        <div className="bg-green-50 p-6 rounded-lg shadow hover:shadow-md transition-shadow">
          <h2 className="text-xl font-semibold text-green-700 mb-2">Appointments</h2>
          <p className="text-gray-600">Schedule and keep track of your medical appointments.</p>
        </div>
        
        <div className="bg-purple-50 p-6 rounded-lg shadow hover:shadow-md transition-shadow">
          <h2 className="text-xl font-semibold text-purple-700 mb-2">Medical Prescriptions</h2>
          <p className="text-gray-600">View and manage your medication prescriptions.</p>
        </div>
        
        <div className="bg-amber-50 p-6 rounded-lg shadow hover:shadow-md transition-shadow">
          <h2 className="text-xl font-semibold text-amber-700 mb-2">Health Reminders</h2>
          <p className="text-gray-600">Stay on top of your health with timely reminders.</p>
        </div>
      </div>
    </div>
  );
}

export default Home;