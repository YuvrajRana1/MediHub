import React, { useState } from 'react';
import { Bell, Menu, X } from 'lucide-react';

function Navbar({ activeTab, onTabChange }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [notificationCount, setNotificationCount] = useState(3);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleTabClick = (tabName) => {
    onTabChange(tabName);
    if (isMenuOpen) {
      setIsMenuOpen(false);
    }
  };

  return (
    <nav className="bg-blue-600 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              
              <span className="font-bold text-xl md:text-2xl ml-2">Digi-Med</span>
            </div>
          </div>
          
          {/* Desktop Navigation - Horizontal Layout */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="flex space-x-1">
              <button 
                onClick={() => handleTabClick('Home')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${activeTab === 'Home' ? 'bg-blue-700' : 'hover:bg-blue-700'}`}
              >
                Home
              </button>
              <button 
                onClick={() => handleTabClick('My Reports')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${activeTab === 'My Reports' ? 'bg-blue-700' : 'hover:bg-blue-700'}`}
              >
                My Reports
              </button>
              <button 
                onClick={() => handleTabClick('Appointment')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${activeTab === 'Appointment' ? 'bg-blue-700' : 'hover:bg-blue-700'}`}
              >
                Appointment
              </button>
              <button 
                onClick={() => handleTabClick('Medical Prescription')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${activeTab === 'Medical Prescription' ? 'bg-blue-700' : 'hover:bg-blue-700'}`}
              >
                Medical Prescription
              </button>
              <button 
                onClick={() => handleTabClick('Health Reminders')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${activeTab === 'Health Reminders' ? 'bg-blue-700' : 'hover:bg-blue-700'}`}
              >
                Health Reminders
              </button>
            </div>
            
            {/* Notification Icon */}
            <div className="relative ml-2">
              <button className="flex items-center justify-center p-2 rounded-full hover:bg-blue-700">
                <Bell size={20} />
                {notificationCount > 0 && (
                  <span className="absolute top-0 right-0 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                    {notificationCount}
                  </span>
                )}
              </button>
            </div>
          </div>
          
          {/* Mobile menu button */}
          <div className="flex items-center md:hidden">
            <button 
              onClick={toggleMenu}
              className="p-2 rounded-md hover:bg-blue-700 focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            
            {/* Notification icon for mobile */}
            <div className="relative ml-4">
              <button className="flex items-center justify-center p-1 rounded-full hover:bg-blue-700">
                <Bell size={20} />
                {notificationCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                    {notificationCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu, show/hide based on menu state */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <button
              onClick={() => handleTabClick('Home')}
              className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left ${
                activeTab === 'Home' ? 'bg-blue-700' : 'hover:bg-blue-700'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleTabClick('My Reports')}
              className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left ${
                activeTab === 'My Reports' ? 'bg-blue-700' : 'hover:bg-blue-700'
              }`}
            >
              My Reports
            </button>
            <button
              onClick={() => handleTabClick('Appointment')}
              className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left ${
                activeTab === 'Appointment' ? 'bg-blue-700' : 'hover:bg-blue-700'
              }`}
            >
              Appointment
            </button>
            <button
              onClick={() => handleTabClick('Medical Prescription')}
              className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left ${
                activeTab === 'Medical Prescription' ? 'bg-blue-700' : 'hover:bg-blue-700'
              }`}
            >
              Medical Prescription
            </button>
            <button
              onClick={() => handleTabClick('Health Reminders')}
              className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left ${
                activeTab === 'Health Reminders' ? 'bg-blue-700' : 'hover:bg-blue-700'
              }`}
            >
              Health Reminders
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}

export default Navbar;