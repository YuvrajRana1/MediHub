import React from 'react';

function MyReports() {
  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">My Reports</h1>
      <p className="text-gray-600 mb-6">This section will display your medical reports.</p>
    </div>
  );
}

export default MyReports;